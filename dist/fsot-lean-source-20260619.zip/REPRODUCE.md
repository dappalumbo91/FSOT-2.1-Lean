# FSOT Formal Verification — Reproduction Guide

This repository machine-checks FSOT domain scalar **signs** and Wave-1 ΛCDM **numeric certificates** at canonical parameters. The formal source is ~0.3 MB; the first Lean build downloads Mathlib (~3 GB under `.lake/`).

## Prerequisites

- **Lean 4** via [elan](https://github.com/leanprover/elan): toolchain `leanprover/lean4:v4.31.0` (see `lean-toolchain`)
- **Python 3.11+** with `pip install -r requirements.txt`
- **fsot_compute.py** authority (or use cached `data/canonical_constants.json`)

## Quick verify (recommended)

```powershell
cd <repo-root>
pip install -r requirements.txt
python scripts/fsot_verification_runner.py
```

On success this:

1. Checks SHA-256 hash gate on `fsot_compute.py`
2. Compares Wave-1 and domain scalars to `data/canonical_constants.json`
3. Runs `lake build` on `FSOT.Formal.*`
4. Writes `data/certificate.json`

## Step-by-step

### 1. Sync canonical constants (optional)

If you have the authority compute engine locally:

```powershell
python scripts/sync_canonical_constants.py
```

### 2. Domain scalar oracle (numeric reference)

```powershell
python scripts/domain_scalar_oracle.py
```

Mirrors `FSOT.Formal.Scalar` term1/term2/term3/raw_S per ledger domain.

### 3. Lean build

```powershell
lake exe cache get
lake build FSOT.Formal.Bounds FSOT.Formal.Theorems FSOT.Formal.Cosmology FSOT.Formal.Domains FSOT
```

### 4. Export certificate only

```powershell
python scripts/export_certificate.py --lean-ok
```

### 5. Source-only release zip

```powershell
python scripts/make_source_release.py
```

Output: `dist/fsot-lean-source-YYYYMMDD.zip` (no `.lake/`).

## Key artifacts

| File | Role |
|------|------|
| `data/proof_ledger.yaml` | Claim ↔ Lean theorem ↔ oracle ↔ physics notes |
| `data/canonical_constants.json` | Pinned numeric cache from authority engine |
| `data/certificate.json` | Portable verification manifest (generated) |
| `FSOT/Formal/Domains.lean` | Per-domain sign theorems |
| `FSOT/Formal/Theorems.lean` | Shared sign/dominance lemmas |
| `FSOT/Formal/Cosmology.lean` | Wave-1 and r_d interval certificates |

## Claim scope (read before citing)

**Proved in Lean:** sign statements and interval bounds at **canonical** domain parameters; Wave-1 formulas at cached `S_cosm`, `S_quant`.

**Numerically verified:** oracle agreement with `fsot_compute.py` via hash gate.

**Not proved:** full FSOT physical interpretation, parameter-space exhaustiveness, or tight r_d ±0.01 Mpc (current certificate: ±0.05 Mpc).

See `docs/arxiv_outline.md` for the full proved / verified / conjectured taxonomy.