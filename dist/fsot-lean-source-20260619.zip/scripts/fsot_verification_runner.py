#!/usr/bin/env python3
"""
FSOT verification runner — numeric oracle for Lean formalization.

Compares canonical constants, domain scalars, and Wave-1 ΛCDM observables
against the authoritative fsot_compute.py engine.
"""

from __future__ import annotations

import argparse
import importlib.util
import json
import subprocess
import sys
from pathlib import Path

from fsot_hash_gate import check_authority, check_cache_gate, scan_mirrors

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data" / "canonical_constants.json"

CANONICAL_PATHS = [
    Path(r"C:\Users\damia\Desktop\FSOT document update\fsot_compute.py"),
    ROOT / "_research" / "FSOT-2.0-code" / "fsot-2.0" / "fsot_2_0.py",
    Path(r"C:\Users\damia\Desktop\FSOT Cosmology Lab\fsot_compute.py"),
]


def load_fsot_compute():
    for path in CANONICAL_PATHS:
        if not path.exists():
            continue
        spec = importlib.util.spec_from_file_location("fsot_compute", path)
        if spec is None or spec.loader is None:
            continue
        mod = importlib.util.module_from_spec(spec)
        sys.modules[spec.name] = mod
        spec.loader.exec_module(mod)
        return mod, path
    raise FileNotFoundError("fsot_compute.py not found in expected locations")


def rel_err(a: float, b: float) -> float:
    if b == 0:
        return abs(a - b)
    return abs(a - b) / abs(b)


def check_constants(mod, cache: dict) -> list[str]:
    issues: list[str] = []
    pairs = [
        ("layer2.k", float(mod.K), float(cache["layer2"]["k"])),
        ("layer2.acoustic_bleed", float(mod.A_BLEED), float(cache["layer2"]["acoustic_bleed"])),
        ("layer2.acoustic_inflow", float(mod.A_IN), float(cache["layer2"]["acoustic_inflow"])),
        ("domain_scalars.S_cosm", float(mod.S_COSM), float(cache["domain_scalars"]["S_cosm"])),
        ("domain_scalars.S_quant", float(mod.S_QUANT), float(cache["domain_scalars"]["S_quant"])),
    ]
    for name, live, cached in pairs:
        err = rel_err(live, cached)
        if err > 1e-12:
            issues.append(f"{name}: cache mismatch ({err:.3e})")
    return issues


def check_wave1(mod, cache: dict, tol: float = 1e-9) -> list[str]:
    issues: list[str] = []
    for result in mod.wave1():
        cached = cache["wave1"].get(result.name)
        if cached is None:
            issues.append(f"wave1 missing in cache: {result.name}")
            continue
        err = rel_err(float(result.computed), float(cached))
        if err > tol:
            issues.append(f"wave1 {result.name}: drift ({err:.3e})")
    return issues


def check_dominance_heuristics(mod) -> list[str]:
    """Sanity checks aligned with FSOT.Formal.Theorems cosmological bounds."""
    issues: list[str] = []
    beta = float(mod.BETA)
    if not (0 < beta < 0.01):
        issues.append(f"beta expected tiny positive, got {beta}")
    if float(mod.A_BLEED) >= float(mod.PHI):
        issues.append("acoustic_bleed should be < phi for bleed bounds")
    return issues


def run_lean_build() -> tuple[bool, str]:
    try:
        proc = subprocess.run(
            [
                "lake",
                "build",
                "FSOT.Formal.Bounds",
                "FSOT.Formal.Theorems",
                "FSOT.Formal.Cosmology",
                "FSOT.Formal.Domains",
                "FSOT",
            ],
            cwd=ROOT,
            capture_output=True,
            text=True,
            check=False,
        )
        ok = proc.returncode == 0
        return ok, proc.stdout + proc.stderr
    except FileNotFoundError:
        return False, "lake not found on PATH"


def print_mirror_scan() -> None:
    print("\n=== Hash-gate mirrors (Desktop fsot_compute.py) ===")
    for row in scan_mirrors():
        if not row["present"]:
            print(f"  {row['label']:14s}  MISSING")
            continue
        status = "OK" if row["matches_expected"] else "MISMATCH"
        digest = row["sha256"][:16]
        print(
            f"  {row['label']:14s}  {status:8s}  "
            f"{row['class']:13s}  {digest}..."
        )


def main() -> int:
    parser = argparse.ArgumentParser(description="FSOT verification runner")
    parser.add_argument("--skip-lean", action="store_true", help="Skip lake build step")
    parser.add_argument("--sync", action="store_true", help="Regenerate canonical_constants.json first")
    parser.add_argument(
        "--no-hash-gate",
        action="store_true",
        help="Skip SHA-256 authority gate checks",
    )
    parser.add_argument(
        "--scan-mirrors",
        action="store_true",
        help="Print Desktop mirror digest table and exit",
    )
    args = parser.parse_args()

    if args.scan_mirrors:
        print_mirror_scan()
        return 0

    if args.sync:
        sync = ROOT / "scripts" / "sync_canonical_constants.py"
        subprocess.run([sys.executable, str(sync)], check=True)

    mod, source = load_fsot_compute()
    print(f"Using compute engine: {source}")

    if not DATA.exists():
        print("canonical_constants.json missing; run with --sync first", file=sys.stderr)
        return 2

    cache = json.loads(DATA.read_text(encoding="utf-8"))
    issues: list[str] = []

    gate_ok, live_digest, gate_issues = check_authority(source)
    if not args.no_hash_gate:
        issues.extend(gate_issues)
        issues.extend(check_cache_gate(cache, live_digest))
        print(f"\n=== Hash gate ===")
        print(f"  authority_sha256 = {live_digest}")
        print(f"  gate             {'OK' if gate_ok else 'FAIL'}")
        print_mirror_scan()

    issues.extend(check_constants(mod, cache))
    issues.extend(check_wave1(mod, cache))
    issues.extend(check_dominance_heuristics(mod))

    print("\n=== Wave 1 (ΛCDM core) ===")
    for r in mod.wave1():
        print(f"  {r.name:20s}  {float(r.computed):.8f}")

    print("\n=== Domain scalars ===")
    print(f"  S_cosm = {float(mod.S_COSM):.8f}")
    print(f"  S_quant = {float(mod.S_QUANT):.8f}")

    if not args.skip_lean:
        print("\n=== Lean build ===")
        ok, log = run_lean_build()
        print("  OK" if ok else "  FAILED")
        if not ok:
            issues.append("Lean build failed")
            print(log[-4000:])

    print("\n=== Summary ===")
    if issues:
        for item in issues:
            print(f"  FAIL: {item}")
        return 1

    print("  All checks passed.")

    export = ROOT / "scripts" / "export_certificate.py"
    if export.exists():
        print("\n=== Certificate export ===")
        lean_ok = not args.skip_lean
        cmd = [
            sys.executable,
            str(export),
            "--authority-path",
            str(source),
        ]
        if lean_ok:
            cmd.append("--lean-ok")
        proc = subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True, check=False)
        print(proc.stdout.strip() or proc.stderr.strip())
        if proc.returncode != 0:
            issues.append("certificate export failed")
            return 1

    return 0


if __name__ == "__main__":
    sys.exit(main())